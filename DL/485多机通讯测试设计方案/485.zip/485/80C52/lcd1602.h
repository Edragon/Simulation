#ifndef  __LCD1602_H_
#define __LCD1602_H_
#include<reg51.h>

#define LCD1602_DATAPINS P0
sbit LCD1602_E=P2^0;
sbit LCD1602_RW=P2^1;
sbit LCD1602_RS=P2^2;

extern void lcd_write_com(unsigned char com);
extern void lcd_write_data(unsigned char dat);	
extern void lcd_init();

#endif
