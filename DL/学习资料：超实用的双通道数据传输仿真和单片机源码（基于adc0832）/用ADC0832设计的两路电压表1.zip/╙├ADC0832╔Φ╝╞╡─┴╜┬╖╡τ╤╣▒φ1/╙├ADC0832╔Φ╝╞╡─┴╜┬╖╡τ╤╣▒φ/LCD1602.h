#ifndef _LCD1602_H_
#define _LCD1602_H_

uchar LCD_check_busy()
{
	uchar state;
	rs=0;
	rw=1;
	delay(2);
	en=1;
	state=P0;
	delay(2);
	en=0;
	delay(2);
	return state;
}
void LCD_write_cmd(uchar cmd)
{
	while((LCD_check_busy()&0x80)==0x80);
	rs=0;
	rw=0;
	delay(2);
	en=1;
	P0=cmd;
	delay(2);
	en=0;
	delay(2);
}				
void LCD_write_data(uchar dat)
{
	while((LCD_check_busy()&0x80)==0x80);
	rs=1;
	rw=0;
	delay(2);
	en=1;
	P0=dat;
	delay(2);
	en=0;
	delay(2);
}
void LCD_display(uchar add,uchar s[])
{
	  uchar i;
	  LCD_write_cmd(0x80+add);
	  for(i=0;i<16;i++)
	  	LCD_write_data(s[i]);
} 
void LCD_init()
{
	LCD_write_cmd(0x38);
	delay(1);
	LCD_write_cmd(0x0c);
	delay(1);
	LCD_write_cmd(0x06);
	delay(1);
	LCD_write_cmd(0x01);
	delay(1);
}

#endif