#ifndef _DEFINE_H_
#define _DEFINE_H_

#define uchar unsigned char
#define uint unsigned int 
sbit cs=P3^0;
sbit clk=P3^1;                 //���ƶ˿ڶ���
sbit dio=P3^2;
sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;
uint j,add,dat;
uchar LCD_buffer[][16]=
{
{"  CH1 =  .   V  "},
{"  CH2 =  .   V  "}
};



#endif