#ifndef _DELAY_H_
#define _DELAY_H_

void delay(uint z)
{
	uint x,y;
	for(y=z;y>0;y--)
		for(x=10;x>0;x--);
}
void delay_us()
{_nop_();_nop_();}	  

#endif