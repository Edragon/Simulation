#include<reg52.h>
#include<intrins.h>
#include"define.h"
#include"delay.h"
#include"LCD1602.h"
#include"ADC0832.h"
 
void main()
{
	LCD_init();
	while(1)
	{
		for(j=0;j<2;j++)
		{
			if(j==0)
				add=0x00;
			else
				add=0x40;
			ADC_change(j);
			LCD_buffer[j][8]=dat/100+'0';
			LCD_buffer[j][10]=dat/10%10+'0';
			LCD_buffer[j][11]=dat%10+'0';	
			LCD_display(add,LCD_buffer[j]);
			delay(1);
		}
	}

}
